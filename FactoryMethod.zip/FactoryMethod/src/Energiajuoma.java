
public class Energiajuoma implements Juoma {
	
	 public String toString(){
	        return "energiajuoma";
	    }
}
