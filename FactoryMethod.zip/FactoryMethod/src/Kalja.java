
public class Kalja implements Juoma {

	 public String toString(){
	        return "kalja";
	    }
}
