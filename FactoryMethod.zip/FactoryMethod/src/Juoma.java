

public interface Juoma {
	
}
