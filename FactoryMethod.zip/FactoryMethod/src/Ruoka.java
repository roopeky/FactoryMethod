
public interface Ruoka {


}
