
public class Juoppo extends AterioivaOtus {

	public Juoma createJuoma(){
        return new Kalja();
    };

}
