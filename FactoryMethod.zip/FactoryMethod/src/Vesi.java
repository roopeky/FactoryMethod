
public class Vesi implements Juoma{

    public String toString(){
        return "vesi";
    }

}
